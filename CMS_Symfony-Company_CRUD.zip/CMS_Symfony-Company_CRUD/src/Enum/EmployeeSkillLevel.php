<?php

namespace App\Enum;

enum EmployeeSkillLevel: string
{
    case EXPERT = 'Expert';
    case INTERMEDIATE = 'Intermediate';
    case BASIC = 'Basic';
}