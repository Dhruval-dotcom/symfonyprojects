<?php

namespace App\Enum;

enum TaskType: string
{
    case TASK = 'Task';
    case BUG = 'Bug';
}