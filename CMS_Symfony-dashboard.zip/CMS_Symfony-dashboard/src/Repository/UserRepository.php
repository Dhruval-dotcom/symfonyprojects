<?php

namespace App\Repository;

use App\Entity\Company;
use App\Entity\User;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\Security\Core\Exception\UnsupportedUserException;
use Symfony\Component\Security\Core\User\PasswordAuthenticatedUserInterface;
use Symfony\Component\Security\Core\User\PasswordUpgraderInterface;

/**
 * @extends ServiceEntityRepository<User>
 *
 * @method User|null find($id, $lockMode = null, $lockVersion = null)
 * @method User|null findOneBy(array $criteria, array $orderBy = null)
 * @method User[]    findAll()
 * @method User[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class UserRepository extends ServiceEntityRepository implements PasswordUpgraderInterface
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, User::class);
    }

    public function save(User $entity, bool $flush = false): void
    {
        $this->getEntityManager()->persist($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    public function remove(User $entity, bool $flush = false): void
    {
        $this->getEntityManager()->remove($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    /**
     * Used to upgrade (rehash) the user's password automatically over time.
     */
    public function upgradePassword(PasswordAuthenticatedUserInterface $user, string $newHashedPassword): void
    {
        if (!$user instanceof User) {
            throw new UnsupportedUserException(sprintf('Instances of "%s" are not supported.', $user::class));
        }

        $user->setPassword($newHashedPassword);

        $this->save($user, true);
    }

    public function dynamicDataAjaxVise(int $limit, int $start, string $orderByField, string $orderDirection, string $searchBy, Company $company): array
    {
        $queryBuilder = $this->createQueryBuilder('u')
            ->orderBy("u.$orderByField", $orderDirection)
            ->andWhere('u.company = :c')
            ->setParameter('c', $company);

        if ($searchBy){
            return $queryBuilder->andWhere('u.username LIKE ?1 OR u.gender LIKE ?1 OR u.dob LIKE ?1 OR u.isVerified LIKE ?1 OR u.isActive LIKE ?1 ')
                ->setParameter(1, '%' . $searchBy . '%')
                ->getQuery()
                ->getResult();
        }

        if ($orderByField === 'company.name') {
            $queryBuilder->innerJoin('u.company', 'company')
                ->orderBy($orderByField, $orderDirection)
                ->addSelect('company');
        }

        return $queryBuilder->setMaxResults($limit)
            ->setFirstResult($start)
            ->getQuery()
            ->getResult();
    }

    public function getTotalUsersCount(Company $company): int
    {
        return count(
            $this->createQueryBuilder('u')
                ->andWhere('u.company = :c')
                ->setParameter('c', $company)
                ->getQuery()
                ->getResult()
        );
    }

    public function dynamicDataApproveUser(int $limit, int $start, string $orderByField, string $orderDirection, string $searchBy, Company $company): array
    {
        $queryBuilder = $this->createQueryBuilder('u')
            ->select('u.id, u.gender, u.email, u.username, u.firstName, u.lastName, u.dob, u.isActive, u.isApproved, u.isVerified')
            ->orderBy("u.$orderByField", $orderDirection)
            ->andWhere('u.company = :c')
            ->setParameter('c', $company);

        if ($searchBy){
            return $queryBuilder->andWhere('u.username LIKE ?1 OR u.gender LIKE ?1 OR u.dob LIKE ?1 OR u.isApproved LIKE ?1 OR u.isActive LIKE ?1 ')
                ->setParameter(1, '%' . $searchBy . '%')
                ->getQuery()
                ->getResult();
        }

        if ($orderByField === 'company.name') {
            $queryBuilder->innerJoin('u.company', 'company')
                ->orderBy($orderByField, $orderDirection)
                ->addSelect('company');
        }

        return $queryBuilder->setMaxResults($limit)
            ->setFirstResult($start)
            ->getQuery()
            ->getResult();
    }
    // public function blockUser($id)
    // {
    //     return $this->createQueryBuilder('u')
    //     ->update('u.isActive', true)
    //     ->where('u.id = :id')
    //     ->setParameter('id', $id)
    //     ->getQuery()
    //     ->getResult()
    //     ;
    // }

    //    /**
    //     * @return User[] Returns an array of User objects
    //     */
    //    public function findByExampleField($value): array
    //    {
    //        return $this->createQueryBuilder('u')
    //            ->andWhere('u.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->orderBy('u.id', 'ASC')
    //            ->setMaxResults(10)
    //            ->getQuery()
    //            ->getResult()
    //        ;
    //    }

    //    public function findOneBySomeField($value): ?User
    //    {
    //        return $this->createQueryBuilder('u')
    //            ->andWhere('u.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->getQuery()
    //            ->getOneOrNullResult()
    //        ;
    //    }
}
