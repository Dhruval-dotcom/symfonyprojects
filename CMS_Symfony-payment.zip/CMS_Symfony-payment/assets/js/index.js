// new DataTable('#company_table', {
//     ajax: 'http://localhost:8000/superadmin/company/register',
//     processing: true,
//     serverSide: true
// });